from django.urls import path
from skiillprintapp import views 
urlpatterns =[
    path('',views.index, name='index'),
    path('signup',views.signup, name='signup'),
    path('login/',views.login_view, name='login'),
    path('logout',views.logout_view, name='logout'),
    path('dashboard',views.dashboard, name='dashboard'),
    path('add',views.add_course, name='add'),
    path('edit_course/<int:course_id>',views.edit_course, name='edit_course'),
    path('delete_course/<int:course_id>',views.delete_course, name='delete_course'),
    path('courses',views.courses, name='courses'),
    path('course_details/<int:course_id>',views.course_details, name='course_details'),

    #Student Dashboard
    path('student_dashboard/<int:course_id>',views.student_dashboard, name='student_dashboard'),
    path('studentDashboard',views.studentDashboard, name='studentDashboard'),
    path('payment/<int:course_id>/', views.payment, name='payment'),
    path('payment', views.payment, name='payment_default'),
    path('save-enrollment', views.saveEnrollment, name='saveEnrollment'),
    
    #Students Tracking
    path('enrolled_students', views.enrolled_students, name='enrolled_students'),
    
    #Forgot Password
    path('forgot_password/',views.forgot_password,name='forgot_password'),
    path('reset_password/<uidb64>/<token>/', views.reset_password, name='reset_password'),
    path('404/', views.page_not_found, name='404')

]