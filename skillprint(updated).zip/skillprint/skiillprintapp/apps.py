from django.apps import AppConfig


class SkiillprintappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'skiillprintapp'
