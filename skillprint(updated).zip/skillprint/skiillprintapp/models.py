from django.db import models
from django.contrib.auth.models import AbstractUser

class Courses(models.Model):
    course_title = models.CharField(max_length=50)
    fees = models.FloatField(default=0)
    duration = models.IntegerField(default=0)
    description = models.CharField(max_length=1000)
    
    # Fields for images
    image_link = models.URLField(max_length=200, null=True, blank=True)
    image_file = models.ImageField(upload_to='course_images/', null=True, blank=True)
    
    # Fields for videos
    video_link = models.URLField(max_length=200, null=True, blank=True)
    video_file = models.FileField(upload_to='course_videos/', null=True, blank=True)
    
    # Fields for notes
    notes_link = models.URLField(max_length=200, null=True, blank=True)
    notes_file = models.FileField(upload_to='course_notes/', null=True, blank=True)

    def __str__(self):
        return self.course_title
    
class NewUser(AbstractUser):
    phone_no = models.CharField(max_length=10, default='')
    courses = models.ManyToManyField(Courses, related_name='students', blank=True)

class Payment(models.Model):
    enrolled_student = models.ForeignKey(NewUser, on_delete=models.CASCADE)
    enrolled_course = models.ForeignKey(Courses, on_delete=models.CASCADE)
    amount_paid = models.FloatField()
    is_paid = models.BooleanField(default=False)
