from django.shortcuts import render, redirect
from .models import *
from django.contrib.auth import login, logout, authenticate
from django.http import HttpResponse, HttpResponseRedirect,JsonResponse, HttpResponseBadRequest
from django.contrib.auth import get_user_model
from django.shortcuts import get_object_or_404
import json, re
from . import utils
from django.contrib.auth.decorators import login_required


User = get_user_model()  # Assuming NewUser is your custom user model

def index(request):
    courses = Courses.objects.all()
    return render(request,'index.html',{'courses':courses})

@login_required(login_url="/404")
def dashboard(request):
    courses = Courses.objects.all()
    return render(request,'dashboard.html',{'courses':courses})

@login_required(login_url="/404")
def enrolled_students(request):
    students = Payment.objects.all()
    return render(request,'enrolled_students.html',{'students':students})

def signup(request):
    if request.method == "POST":
        first_name = request.POST.get('name')
        email = request.POST.get('email')
        phone_no = request.POST.get('phone_number')
        username = request.POST.get('username')
        password = request.POST.get('password')
        courseId = int(request.POST.get('courseId', None))
        enrolled_course = get_object_or_404(Courses, id=courseId) if courseId else None

        try:
            if courseId and NewUser.objects.filter(username=username).exists():
                user = authenticate(request, username=username, password=password)
                if user is not None:
                    login(request, user)
                    usr = NewUser.objects.get(username=username)
                    return render(request, "signup.html", {'std_exists': True, 'userID': usr.id, 'courseId':courseId})
            else:
                new_student = NewUser(
                    username=username,
                    email=email,
                    first_name=first_name,
                    phone_no=phone_no,
                )
                new_student.set_password(password)
                new_student.save()  # Save the new_user instance first

                if enrolled_course:
                    new_student.courses.add(enrolled_course)  # Add the course after saving new_user

                user = authenticate(request, username=username, password=password)
                if user is not None:
                    login(request, user)
                    if enrolled_course:
                        return redirect(f'/payment/{enrolled_course.id}')
                    else:
                        return redirect('/')
        except Exception as e:
            print(f"Error during registration: {e}")
            return render(request, "signup.html", {'error': str(e)})

    return render(request, "signup.html")
 
def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)

            if user.is_superuser and user.is_staff and user.is_active:
                return redirect('dashboard')  # Redirect to admin dashboard if superuser/staff
            else:
                try:
                    user_courses = user.courses.all()
                    payments = Payment.objects.filter(enrolled_student=user)
                    if payments.exists() and payments.filter(is_paid=True).exists():
                        return redirect('studentDashboard')  # Redirect to dashboard if payment is done
                    else:
                        return render(request, "login.html", {"payment_error": True, "username": username, "courses": user_courses})  # Pass courses to template context
                except Payment.DoesNotExist:
                    user_courses = user.courses.all()  # Retrieve courses even if Payment does not exist
                    return render(request, "login.html", {"payment_error": True, "username": username, "courses": user_courses})  # No payment record found

        return render(request, "login.html", {'login_error': True, 'msg': "Invalid Username or Password."})

    return render(request, 'login.html', {'login_error': False})

def payment(request, course_id=None):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            fees = float(data.get('fees'))
            course_id = int(data.get('course'))

            enrolled_course = get_object_or_404(Courses, id=course_id)

            pay = Payment(
                enrolled_student=request.user,
                enrolled_course=enrolled_course,
                amount_paid=fees,
                is_paid=True
            )
            pay.save()

            extra = {
                'student_name': request.user.first_name,
                'course_name': enrolled_course.course_title,
                'fees': enrolled_course.fees,
                'duration': enrolled_course.duration,
                'description': enrolled_course.description,
                'notes_link': enrolled_course.notes_link if enrolled_course.notes_link else enrolled_course.notes_file.url
            }

            status, msg = utils.confirmation_mail(request.user.email, extra)
            if status:
                print("Course enrollment confirmation email sent.")
            else:
                print("Failed to send course enrollment confirmation email because of the following error.")
                print(msg)

            return JsonResponse({'success': True, 'res': True if status else False})
        except json.JSONDecodeError as e:
            print("Error decoding JSON: ", e)
            return JsonResponse({'success': False, 'error': 'Invalid JSON format'}, status=400)
        except Courses.DoesNotExist:
            print("Course not found with ID: ", course_id)
            return JsonResponse({'success': False, 'error': 'Course not found'}, status=404)
        except Exception as e:
            print("Unexpected error: ", str(e))
            return JsonResponse({'success': False, 'error': str(e)}, status=500)

    enrolling_course = get_object_or_404(Courses, id=course_id)
    context = {'enrolling_course': enrolling_course}
    return render(request, 'payment.html', context)


def saveEnrollment(request):
    if request.method == "PUT":
        try:
            data = json.loads(request.body)
            courseId = data.get('courseId')
            userId = data.get('userId')

            course = get_object_or_404(Courses, id=courseId)
            user = get_object_or_404(NewUser, id=userId)
            
            user.courses.add(course)
            user.save() 
            print('done')
            return JsonResponse({'success': True})
        except Exception as e:
            print("error")
            return JsonResponse({'success': False, 'error': str(e)}, status=500)
    
    return JsonResponse({'success': False, 'error': "Invalid Request"}, status=500)

def student_dashboard(request,course_id):
    courses = Courses.objects.filter(id = course_id)
    return render(request,"student_dashboard.html", {'courses':courses})

@login_required(login_url="/404")
def studentDashboard(request):
    user_courses = request.user.courses.all()
    return render(request, "student_dashboard.html", {'courses': user_courses})

@login_required(login_url="/404")
def logout_view(request):
    logout(request)
    return redirect('/')

def course_details(request,course_id):
    course_details = Courses.objects.get(id=course_id)
    return render(request,'course-details.html',{'course_details':course_details})

def courses(request):
    courses = Courses.objects.all()
    return render(request,'courses.html',{'courses':courses})

def extract_video_id(url):
    """
    Function to extract YouTube video ID from URL.
    Handles different YouTube URL formats.
    """
    regex_list = [
        r"(?:https:\/\/)?(?:www\.)?youtube\.com\/(?:watch\?v=|embed\/|v\/|shorts\/)([^&?\/]+)",
        r"(?:https:\/\/)?(?:www\.)?youtu\.be\/([^&?\/]+)"
    ]

    for regex in regex_list:
        match = re.search(regex, url)
        if match:
            return match.group(1)  # Return the video ID found

    return None  # Return None if no valid video ID found

def convert_to_embed_url(url):
    """
    Function to convert a YouTube video URL to embed format.
    """
    video_id = extract_video_id(url)
    if video_id:
        embed_url = f"https://www.youtube.com/embed/{video_id}"
        return embed_url
    return None

@login_required(login_url="/404")
def add_course(request):
    if request.method == 'POST':
        course_title = request.POST.get('course_title')
        fees = request.POST.get('fees')
        duration = request.POST.get('duration')
        description = request.POST.get('description')

        # Handle image input
        image_upload_option = request.POST.get('image_upload_option')
        image_link = request.POST.get('image_link') if image_upload_option == 'link' else None
        image_file = request.FILES.get('image_file') if image_upload_option == 'file' else None

        # Handle video input
        video_upload_option = request.POST.get('video_upload_option')
        video_link = request.POST.get('video_link') if video_upload_option == 'link' else None
        video_file = request.FILES.get('video_file') if video_upload_option == 'file' else None

        # Handle notes input
        notes_upload_option = request.POST.get('notes_upload_option')
        notes_link = request.POST.get('notes_link') if notes_upload_option == 'link' else None
        notes_file = request.FILES.get('notes_file') if notes_upload_option == 'file' else None

        # Convert video_link to standard embed format if necessary
        if video_link:
            embed_url = convert_to_embed_url(video_link)
            if embed_url:
                video_link = embed_url
            else:
                return HttpResponseBadRequest("Invalid YouTube video link")

        # Create a new Courses object and save it to the database
        new_course = Courses(
            course_title=course_title,
            fees=fees,
            duration=duration,
            description=description,
            image_link=image_link,
            video_link=video_link,
            notes_link=notes_link
        )

        # Save files if they were uploaded
        if image_file:
            new_course.image_file = image_file
        if video_file:
            new_course.video_file = video_file
        if notes_file:
            new_course.notes_file = notes_file

        new_course.save()

        # Redirect to the trainer dashboard with a status parameter
        return render(request, 'add.html', {'status': True})

    return render(request, 'add.html')

def extract_video_id(url):
    """
    Function to extract YouTube video ID from URL.
    Handles different YouTube URL formats.
    """
    regex_list = [
        r"(?:https:\/\/)?(?:www\.)?youtube\.com\/(?:watch\?v=|embed\/|v\/|shorts\/)([^&?\/]+)",
        r"(?:https:\/\/)?(?:www\.)?youtu\.be\/([^&?\/]+)"
    ]

    for regex in regex_list:
        match = re.search(regex, url)
        if match:
            return match.group(1)  # Return the video ID found

    return None  # Return None if no valid video ID found

def convert_to_embed_url(url):
    """
    Function to convert a YouTube video URL to embed format.
    """
    video_id = extract_video_id(url)
    if video_id:
        embed_url = f"https://www.youtube.com/embed/{video_id}"
        return embed_url
    return None

@login_required(login_url="/404")
def edit_course(request, course_id):
    record = get_object_or_404(Courses, id=course_id)

    if request.method == "POST":
        # Update fields based on form data
        record.course_title = request.POST.get('course_title', record.course_title)
        record.fees = request.POST.get('fees', record.fees)
        record.duration = request.POST.get('duration', record.duration)
        record.description = request.POST.get('description', record.description)

        # Handle image input
        image_upload_option = request.POST.get('image_upload_option')
        if image_upload_option == 'link':
            image_link = request.POST.get('image_link')
            if image_link:
                record.image_link = image_link
                record.image_file = None  # Clear file if link is provided
        elif image_upload_option == 'file':
            image_file = request.FILES.get('image_file')
            if image_file:
                record.image_file = image_file
                record.image_link = None  # Clear link if file is uploaded

        # Handle video input
        video_upload_option = request.POST.get('video_upload_option')
        if video_upload_option == 'link':
            video_link = request.POST.get('video_link')
            if video_link:
                embed_url = convert_to_embed_url(video_link)
                if embed_url:
                    record.video_link = embed_url
                    record.video_file = None  # Clear file if link is provided
                else:
                    return HttpResponseBadRequest("Invalid YouTube video link")
        elif video_upload_option == 'file':
            video_file = request.FILES.get('video_file')
            if video_file:
                record.video_file = video_file
                record.video_link = None  # Clear link if file is uploaded

        # Handle notes input
        notes_upload_option = request.POST.get('notes_upload_option')
        if notes_upload_option == 'link':
            notes_link = request.POST.get('notes_link')
            if notes_link:
                record.notes_link = notes_link
                record.notes_file = None  # Clear file if link is provided
        elif notes_upload_option == 'file':
            notes_file = request.FILES.get('notes_file')
            if notes_file:
                record.notes_file = notes_file
                record.notes_link = None  # Clear link if file is uploaded

        record.save()  # Save the updated Courses object to the database
        return redirect('dashboard')  # Redirect to dashboard or any other page as needed

    else:
        return render(request, 'edit_course.html', {'row': record})
    
@login_required(login_url="/404")
def delete_course(request, course_id):
    if request.method == 'DELETE':
        course = get_object_or_404(Courses, id=course_id)
        course.delete()
        return JsonResponse({'msg': f'Course {course_id} deleted successfully.'})
    else:
        return JsonResponse({'error': 'Method not allowed.'}, status=405)
    
def forgot_password(request):
    if request.method == "POST":
        email = request.POST.get("email")
        status = utils.send_reset_email(email)
        print(f"email => {email}")
        if status[0]:
            return render(request, 'forgot_password.html', {'status': True, 'link': True,'message': 'A reset link has been sent to your email.'})
        else:
            return render(request, 'forgot_password.html', {'status': False, 'message': 'No User Found Registered with given email ID. Please try again.'})

    return render(request, 'forgot_password.html', {'status': False})

from django.contrib.auth.tokens import default_token_generator
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str

def reset_password(request, uidb64, token):
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = NewUser.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, NewUser.DoesNotExist):
        user = None

    if user is not None and default_token_generator.check_token(user, token):
        if request.method == "POST":
            password = request.POST.get('password')
            confirm_password = request.POST.get('confirm_password')

            if password == confirm_password:
                user.set_password(password)
                user.save()
                if user:
                    return redirect('login/?status=1')
            else:
                return render(request, 'reset_password.html', {'validlink': True, 'message': 'Passwords do not match.'})

        return render(request, 'reset_password.html', {'validlink': True})
    else:
        return render(request, 'reset_password.html', {'validlink': False})
    
def page_not_found(request):
    return render(request,'404.html')