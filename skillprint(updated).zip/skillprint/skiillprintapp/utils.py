#Email related import statements
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from .models import NewUser
from django.conf import settings

#Password Reset related imports statements
from .models import NewUser
from django.contrib.auth.tokens import default_token_generator
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str
from django.urls import reverse
from django.conf import settings

From = "parashurampoojar96@gmail.com"
app_password = "nqlaxrnzdhxzwfny"

def send_email(To, subject, body):
    message = MIMEMultipart()
    message["From"] = From
    message["To"] = To
    message["Subject"] = subject

    # Add HTML body to email
    message.attach(MIMEText(body, "html"))

    try:
        # Connect to SMTP server and send email
        with smtplib.SMTP("smtp.gmail.com", 587) as server:
            server.starttls()
            server.login(From, app_password)
            server.sendmail(From, To, message.as_string())
        
        return True, "Mail sent successfully."
    except Exception as e:
        return False, str(e)

def confirmation_mail(To, extra=None):
    student_name = extra.get('student_name', '')

    course_name = extra.get('course_name', '')
    course_fees = extra.get('fees', '')
    course_duration = extra.get('duration', '')
    course_description = extra.get('description', '')
    notes_link = extra.get('notes_link', '')

    subject = "Course Enrollment Confirmation"
    body = f"""
        <div style="
            margin: 0 auto; 
            text-align: center; 
            border: 1px solid #ccc;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            width: 500px;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 10px;
            font-family: Arial, sans-serif;
        ">
            <h2 style="color: #1845ad;">Enrollment Confirmation</h2>
            <p style="font-size: 16px;">
                Dear {student_name},
            </p>
            <p>
                You have successfully enrolled in the following course:
            </p>
            <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
                <tr>
                    <th style="border: 1px solid #ddd; padding: 8px; background-color: #f2f2f2;">Course Title</th>
                    <th style="border: 1px solid #ddd; padding: 8px; background-color: #f2f2f2;">Fees</th>
                    <th style="border: 1px solid #ddd; padding: 8px; background-color: #f2f2f2;">Duration</th>
                    <th style="border: 1px solid #ddd; padding: 8px; background-color: #f2f2f2;">Description</th>
                </tr>
                <tr>
                    <td style="border: 1px solid #ddd; padding: 8px;">{course_name}</td>
                    <td style="border: 1px solid #ddd; padding: 8px;">₹{course_fees}</td>
                    <td style="border: 1px solid #ddd; padding: 8px;">{course_duration}</td>
                    <td style="border: 1px solid #ddd; padding: 8px; text-align: justify;">{course_description}</td>
                </tr>
            </table>
            <p>
                <a href="{notes_link}" style="
                    display: inline-block;
                    margin: 20px 0;
                    padding: 10px 20px;
                    color: #ffffff;
                    background-color: #1845ad;
                    text-decoration: none;
                    border-radius: 5px;
                ">Download Course Notes</a>
            </p>
            <p style="color: red;">
                Note: This is an auto-generated email. Please do not reply.
            </p>
        </div>
    """

    return send_email(To, subject, body)

def send_reset_email(To):
    try:
        user = NewUser.objects.get(email=To)
        uid = urlsafe_base64_encode(force_bytes(user.pk))
        token = default_token_generator.make_token(user)
        reset_link = f"{settings.SITE_URL}{reverse('reset_password', kwargs={'uidb64': uid, 'token': token})}"
        
        subject = "Password Reset Request"
        body = f"""
            <div style="
                    margin: 0 auto; 
                    text-align:center; 
                    border: 1px solid grey;
                    box-shadow: -3px 3px 5px black;
                    width: 500px;
                    background: #f9f9f9;
                    padding: 20px;
                    border-radius: 20px;
                ">
                <h2>Password Reset Request</h2>
                <p style="font-size: 16px;">
                    Hi <span style="color: transparent; 
                        background: linear-gradient(to right, #1845ad, #23a2f6, #ff512f, #f09819); 
                        -webkit-background-clip: text; background-clip: text;">
                        {user.username}
                    </span>,
                </p>
                <p>We received a request to reset your password. Click the link below to reset your password:</p>
                <a href="{reset_link}" style="
                    display: inline-block;
                    margin: 20px 0;
                    padding: 10px 20px;
                    color: #ffffff;
                    background-color: #1845ad;
                    text-decoration: none;
                    border-radius: 5px;
                ">Reset Password</a>
                <pre>
            OR Copy past it in browser => \n <a href="{reset_link}">{reset_link}</a>
                </pre>
                <p style='color: red;'> Note : If you did not request a password reset, please ignore this email.</p>
            </div>
            """
        
        return send_email(To, subject, body)
    except NewUser.DoesNotExist as e:
        print(e)
        return False, "User Doesn't Exists..."
