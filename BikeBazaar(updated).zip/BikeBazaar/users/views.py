import json
from django.shortcuts import render
from django.shortcuts import render,redirect
#from django.contrib.auth.models import NewUser,
from django.contrib.auth.hashers import make_password
from django.contrib.auth import authenticate,login ,logout
from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, HttpResponse
from .models import *


def seller_logout(request):
    logout(request)
    return redirect('/')

def admin_logout(request):
    logout(request)
    return redirect('/')


def user_logout(request):
    logout(request)
    return redirect('/')

def index(request):
    cars = Cars.objects.filter(is_sold=False)
    return render(request,'index.html',{'cars':cars})

def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:    
            login(request, user)
            # Redirect to a success page.
            return redirect('user_db')  # Replace 'NewUser_dashboard' with the name of your success URL
        else:
            # Return an 'invalid login' error message.
            error_message = "Invalid Username or password."
            messages.error(request, error_message)
            return render(request, 'login.html')
    else:
        return render(request, 'login.html')

def registration(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        first_name = request.POST.get('first_name')
        password = request.POST.get('password')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        last_name = request.POST.get('last_name')
        
        passw = make_password(password)

        if NewUser.objects.filter(email=email).exists():
            return render(request, "registration.html", {'exists': True, 'error': 'User with this email already exists.'})
        
        user = NewUser.objects.create(username=username, password=passw, email=email, first_name=first_name,
                                          last_name=last_name, phone=phone)
        if user:
            return redirect('user_login')  # Replace 'user_login' with your actual login URL
        
    return render(request, "registration.html", {'exists': False})



def seller_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None and user.is_staff:  # Check if the authenticated NewUser is a staff member
            login(request, user)
            # Redirect to a success page.
            return redirect('seller_db')  # Replace 'seller_db' with the name of your success URL
        else:
            # Return an 'invalid login' error message.
            error_message = "Invalid username or password."
            messages.error(request, error_message)
            return render(request, 'seller_login.html')
    else:
        return render(request, 'seller_login.html')

def seller_registration(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        first_name = request.POST.get('first_name')
        password = request.POST.get('password')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        last_name = request.POST.get('last_name')   
        passw = make_password(password)

        if NewUser.objects.filter(email=email).exists():
            return render(request, "seller_registration.html", {'exists': True, 'error': "User with email already exists."})
        
        user = NewUser.objects.create(username=username, password=passw, email=email, first_name=first_name,
                                      last_name=last_name, is_staff=True, phone=phone)
        if user:
            return redirect('seller_login')
        
    return render(request, "seller_registration.html",{'exists': False})

@login_required(login_url="/404")
def seller_db(request):
    # Fetch all cars for the currently logged-in seller
    seller = request.user
    cars = Cars.objects.filter(seller=seller)
    profit = 0
    loss = 0
    if cars.exists():
        for car in cars:
            if car.is_sold:
                profit += car.price
            else:
                loss += car.price
    context = {
        'seller': seller,
        'cars': cars,
        'name': request.user.username,
        'profit':profit,
        'loss':loss
    }
    
    return render(request, 'seller_db.html', context)

@login_required(login_url="/404")
def sell_bike(request):
    if request.method == 'POST':
        car_name = request.POST.get('car_name')
        model = request.POST.get('model')
        fuel_type = request.POST.get('fuel_type')
        transmission = request.POST.get('transmission')
        mileage = request.POST.get('mileage')
        price = request.POST.get('price')
        year = request.POST.get('year')
        number_of_seats = request.POST.get('number_of_seats')
        ac = request.POST.get('ac') == 'True'
        description = request.POST.get('description')
        location = request.POST.get('location')
        image = request.FILES.get('image')
        Cars.objects.create(
            car_name=car_name,
            model=model,
            fuel_type=fuel_type,
            transmission=transmission,
            mileage=mileage,
            price=price,
            year=year,
            number_of_seats=number_of_seats,
            ac=ac,
            description=description,
            image=image,
            location = location,
            seller=request.user  # Assumes seller is the logged-in user
        )

        return render(request, 'sell_bike.html', {'name': request.user.username,'status' :True})

    return render(request, 'sell_bike.html', {'name': request.user.username})

@login_required(login_url="/404")
def edit_car(request, id):
    car = get_object_or_404(Cars, id=id, seller=request.user)
    if request.method == 'POST':
        car.car_name = request.POST.get('car_name', car.car_name)
        car.model = request.POST.get('model', car.model)
        car.fuel_type = request.POST.get('fuel_type', car.fuel_type)
        car.transmission = request.POST.get('transmission', car.transmission)
        car.mileage = request.POST.get('mileage', car.mileage)
        car.price = request.POST.get('price', car.price)
        car.year = request.POST.get('year', car.year)
        car.number_of_seats = request.POST.get('number_of_seats', car.number_of_seats)
        car.ac = request.POST.get('ac', car.ac)
        car.description = request.POST.get('description', car.description)
        car.location = request.POST.get('location', car.location)
        
        # Handle image file upload
        if 'image' in request.FILES:
            car.image = request.FILES['image']
        
        car.save()
        return redirect('seller_db')

    return render(request, 'edit_car.html', {'data': car, 'name': request.user.username})

@login_required(login_url="/404")
def delete_car(request, bike_id):
    car = get_object_or_404(Cars, id=bike_id, seller=request.user.id)
    car.delete()
    messages.success(request, 'Bike deleted successfully!')
    return redirect('seller_db')

@login_required(login_url="/login_view")
def user_db(request):
    data = Cars.objects.filter(is_sold=False)
    return render(request, 'user_db.html',{'data':data})

from django.db.models import Q
@login_required(login_url="/login_view")
def search_user_db(request):
    query = request.GET.get('query', '')
    price = request.GET.get('price', '')

    filters = Q()
    if query:
        filters |= Q(car_name__icontains=query) | Q(model__icontains=query)  # Assuming you want to search both car_name and model fields
    if price:
        filters |= Q(price__icontains=price)

    data = Cars.objects.filter(filters)
    liked_bike = Like_bike.objects.filter(seller=request.user).values_list('car_id', flat=True)
    for bike in data:
        bike.is_liked = bike.id in liked_bike

    return render(request, 'user_db.html', {'data': data, 'query': query, 'price': price})

@login_required(login_url="/login_view")
def single_car(request, id, seller_id):
    car = get_object_or_404(Cars, id=id)
    user_details = NewUser.objects.get(id=request.user.id)
    
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone_no = request.POST.get('phone_no')
        address = request.POST.get('address')

        # Create a booking instance
        booking = Booking_details.objects.create(
            seller=seller_id,
            user_id=request.user,
            car_id=car,  # Pass the Car instance, not the ID
            name=name,
            email=email,
            phone_no=phone_no,
            address=address
        )

        return JsonResponse({'success': True, 'seller': {'first_name': car.seller.first_name, 'email': car.seller.email, 'phone': car.seller.phone}})

    return render(request, 'single_bike.html', {'data': car, 'user_details': user_details, 'success': False})

@login_required(login_url="/login_view")
def booked_cars(request):
    data=Booking_details.objects.select_related('car_id_id').filter(seller=request.user.id)
    return render(request,'booking_details.html',{'data':data,'name':request.user.username})


@login_required(login_url="/404")
def cancel_booking(request,booking_id, car_id):
    booking = get_object_or_404(Booking_details, id=booking_id)
    print( "cancellled Buyer details => ",booking.email, booking.phone_no)
    car = get_object_or_404(Cars, id=car_id)
    booking.status = 'pending'
    car.is_sold=False       
    booking.save()
    car.save()
    print('location ',car.location)      

    try:
        extra = {
        'subject' : "Cancellation Email of your Booking.",
        'body' : "Your Booking get Cancelled. Please contact below person",
        'name': booking.name,
        'phone': booking.phone_no,
        'contact_location' : car.location,
        'email': booking.email,
        'contact_location' : car.location,
        
        }
        status , msg = confirmation_mail(booking.email, extra) 
        if status :
            print("status", status)
            return redirect('seller_booking_details')
        else:
            print("status", status)
            return HttpResponse(f"<h1 style='text-align:center; color: red;'>Someting went wrong; Can't send confirmation email !!! </h1><br> {msg}")
    except Exception as e:
            return HttpResponse(f"<h1 style='text-align:center; color: red;'>Someting went wrong; Can't send confirmation email !!! </h1><br> {str(e)}")

@login_required(login_url="/404")
def seller_booking_details(request):
    data = Booking_details.objects.filter(car_id__seller=request.user)
    return render(request, 'seller_booking_details.html', {'data': data, 'name': request.user.username})

from . utils import *
@login_required(login_url="/404")
def confirm_booking(request,booking_id, car_id):
    booking = get_object_or_404(Booking_details, id=booking_id)
    print("Buyer details => ",booking.email, booking.phone_no)
    car = get_object_or_404(Cars, id=car_id)
    booking.status = 'confirmed'
    car.is_sold=True 
    booking.save()
    car.save()
    print('location ',car.location)      

    try:
        extra = {
        'subject' : "Confirmation Email of your Booking.",
        'body' : "Your Booking get Confirmed. Please contact below person",
        'name': booking.name,
        'phone': booking.phone_no,
        'email': booking.email,
        'contact_location' : car.location,
        }
        status, msg = confirmation_mail(booking.email, extra)
        if status:
            print("status", status)
            return redirect('seller_booking_details')
        else:
            print("status", status)
            
            return HttpResponse(f"<h1 style='text-align:center; color: red;'>Someting went wrong; Can't send confirmation email !!! </h1><br>{msg}")
    except Exception as e:
            return HttpResponse(f"<h1 style='text-align:center; color: red;'>Someting went wrong; Can't send confirmation email !!! </h1><br> {str(e)}")
    
def forgot_password(request):
    if request.method == "POST":
        email = request.POST.get("email")
        status = send_reset_email(email)
        if status[0]:
            return render(request, 'forgot_password.html', {'status': True, 'link': True,'message': 'A reset link has been sent to your email.'})
        else:
            return render(request, 'forgot_password.html', {'status': False, 'message': 'No User Found Registered with given email ID. Please try again.'})

    return render(request, 'forgot_password.html', {'status': False})


from django.contrib.auth.tokens import default_token_generator
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str

def reset_password(request, uidb64, token):
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = NewUser.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, NewUser.DoesNotExist):
        user = None

    if user is not None and default_token_generator.check_token(user, token):
        if request.method == "POST":
            password = request.POST.get('password')
            confirm_password = request.POST.get('confirm_password')

            if password == confirm_password:
                user.set_password(password)
                user.save()
                if user.is_staff:
                    return redirect('seller_login')  # Redirect to seller login page if he is a seller
                else:
                    return redirect('user_login')  # Redirect to seller login page if he is a normal user

            else:
                return render(request, 'reset_password.html', {'validlink': True, 'message': 'Passwords do not match.'})

        return render(request, 'reset_password.html', {'validlink': True})
    else:
        return render(request, 'reset_password.html', {'validlink': False})

def page_not_found(request):
    return render(request,'404.html')