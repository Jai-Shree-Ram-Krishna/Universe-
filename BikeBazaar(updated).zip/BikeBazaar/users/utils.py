import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import os

from .models import NewUser
from django.contrib.auth.tokens import default_token_generator
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str
from django.urls import reverse
from django.conf import settings

From = "parashurampoojar96@gmail.com"
app_password = "nqlaxrnzdhxzwfny"

def send_email(To, subject, body):
    message = MIMEMultipart()
    message["From"] = From
    message["To"] = To
    message["Subject"] = subject

    # Add body to email
    message.attach(MIMEText(body, "html"))

    try:
        # Connect to SMTP server and send email
        with smtplib.SMTP("smtp.gmail.com", 587) as server:
            server.starttls()
            server.login(From, app_password)
            server.sendmail(From, To, message.as_string())
        
        return True, "mail Sent successfuly."
    except Exception as e:
        return False, e

def confirmation_mail(To, extra=None):
    subject = extra['subject']
    body = f"""
        <div style="
                margin: 0 auto; 
                text-align:center; 
                border: 1px solid grey;
                box-shadow: -3px 3px 5px black;
                width: 500px;
                background: pink;
            ">
            <b> {extra['body']} </b>
            <p> Seller Name : {extra['name']} </p>
            <p> Phone Number : {extra['phone']} </p>
            <p> Email Address : {extra['email']} </p>
            <p> Contact Location : {extra.get('location', 'hubli Vidyanagar')} </p>
        </div>"""

    return send_email(To, subject, body)

def send_reset_email(To):
    try:
        user = NewUser.objects.get(email=To)
        uid = urlsafe_base64_encode(force_bytes(user.pk))
        token = default_token_generator.make_token(user)
        reset_link = f"{settings.SITE_URL}{reverse('reset_password', kwargs={'uidb64': uid, 'token': token})}"
        
        subject = "Password Reset Request"
        body = f"""
            <div style="
                    margin: 0 auto; 
                    text-align:center; 
                    border: 1px solid grey;
                    box-shadow: -3px 3px 5px black;
                    width: 500px;
                    background: #f9f9f9;
                    padding: 20px;
                    border-radius: 20px;
                ">
                <h2>Password Reset Request</h2>
                <p style="font-size: 16px;">
                    Hi <span style="color: transparent; 
                        background: linear-gradient(to right, #1845ad, #23a2f6, #ff512f, #f09819); 
                        -webkit-background-clip: text; background-clip: text;">
                        {user.username}
                    </span>,
                </p>
                <p>We received a request to reset your password. Click the link below to reset your password:</p>
                <a href="{reset_link}" style="
                    display: inline-block;
                    margin: 20px 0;
                    padding: 10px 20px;
                    color: #ffffff;
                    background-color: #1845ad;
                    text-decoration: none;
                    border-radius: 5px;
                ">Reset Password</a>
                <pre>
                    OR Copy past it in browser => \n <a href="{reset_link}">{reset_link}</a>
                </pre>
                <p style='color: red;'> Note : If you did not request a password reset, please ignore this email.</p>
            </div>
            """
        
        return send_email(To, subject, body)
    except NewUser.DoesNotExist as e:
        print(e)
        return False, "User Doesn't Exists..."

    
