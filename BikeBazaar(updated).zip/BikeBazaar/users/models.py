from django.db import models


# Create your models here.
from django.contrib.auth.models import AbstractUser


class NewUser(AbstractUser):
    phone = models.IntegerField(default=None)

class Booking_details(models.Model):
    seller=models.CharField(max_length=100,default='0')
    user_id=models.ForeignKey('NewUser', on_delete=models.CASCADE)
    car_id=models.ForeignKey('Cars', on_delete=models.CASCADE)
    name=models.CharField(max_length=100,default='xyz')
    email=models.CharField(max_length=100,default='xyz')
    phone_no=models.CharField(max_length=100,default='xyz')
    address=models.CharField(max_length=100,default='xyz')
    status=models.CharField(max_length=100,default='pending')

class Like_bike(models.Model):
    seller=models.ForeignKey(NewUser, on_delete=models.CASCADE,default='1')
    car_id = models.ForeignKey('Cars', on_delete=models.CASCADE)
   

class Cars(models.Model):
    car_name = models.CharField(max_length=100)
    model = models.CharField(max_length=50)
    fuel_type = models.CharField(max_length=20)
    transmission = models.CharField(max_length=20)
    mileage = models.PositiveIntegerField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    year = models.IntegerField()
    number_of_seats = models.PositiveIntegerField()
    ac = models.BooleanField(default=False)
    description = models.TextField(blank=True, null=True)
    location = models.CharField(max_length=100)
    seller = models.ForeignKey(NewUser, on_delete=models.CASCADE)
    image = models.ImageField(upload_to="carImages")
    is_sold = models.BooleanField(default=False)  # New field added

