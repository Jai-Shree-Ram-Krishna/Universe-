from django.urls import path,include
from . import views
from django.contrib import admin

urlpatterns=[
    
    path('',views.index,name='index'),

    path('user_login',views.user_login,name='user_login'),
    path('registration',views.registration,name='registration'),
    path('seller_registration',views.seller_registration,name='seller_registration'),
    path('seller_login',views.seller_login,name='seller_login'),
    path('seller_logout',views.seller_logout,name='seller_logout'),
    path('user_logout',views.user_logout,name='user_logout'),
    path('seller_db',views.seller_db,name='seller_db'),
    # path('cancel_booking/<int:booking_id>/',views.cancel_booking,name='cancel_booking'),
  
    path('sell_bike',views.sell_bike,name='sell_bike'),
    path('edit_car/<int:id>',views.edit_car,name='edit_car'),
    path('delete_car/<int:bike_id>/', views.delete_car, name='delete_car'),
    path('booked_cars',views.booked_cars,name='booked_cars'),
    path('seller_booking_details',views.seller_booking_details,name='seller_booking_details'),

    #User
    path('user_db',views.user_db,name='user_db'),
    path('search_user_db',views.search_user_db,name='search_user_db'),

    path('single_car/<int:id>/<int:seller_id>',views.single_car,name='single_car'),
    path('confirm/<int:booking_id>/<int:car_id>', views.confirm_booking, name='confirm_booking'),

    path('cancel/<int:booking_id>/<int:car_id>', views.cancel_booking, name='cancel_booking'),


    #Forgot Password
    path('forgot_password/',views.forgot_password,name='forgot_password'),
    path('reset_password/<uidb64>/<token>/', views.reset_password, name='reset_password'),

    path('404/', views.page_not_found, name='404')

]
